#
# Here be some workplace to test stuff and learn
#
