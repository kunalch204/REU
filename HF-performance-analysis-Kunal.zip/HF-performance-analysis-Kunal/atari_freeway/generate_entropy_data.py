import csv
from pathlib import Path
from extract_data import *
import os

# input files
# .bz2
tar_filename = "atari/617_RZ_5374717_Aug-09-13-19-21.tar.bz2"
txt_filename = "atari/617_RZ_5374717_Aug-09-13-19-21.txt"
json_file = "data/freeway/617_RZ_5374717_Aug-09-13-19-21.json"

# convert a game frame to data
if not Path(json_file).exists():
    dataset = Dataset(tar_filename, txt_filename)

# output filename manipulation
trial_name = txt_filename.split('/')[1].split('.')[0]

# output file names
demo_dataset_file = 'data/freeway/'+str(trial_name)+'/demo.csv'
demo_dataset_file = Path(demo_dataset_file)
demo_dataset_file.parent.mkdir(parents=True, exist_ok=True)

demo_gaze_dataset_file = 'data/freeway/'+str(trial_name)+'/demo_gaze.csv'
demo_gaze_dataset_file = Path(demo_gaze_dataset_file)
demo_gaze_dataset_file.parent.mkdir(parents=True, exist_ok=True)

# write final data (for entropy calculation) in output files
with open(demo_dataset_file, 'w', newline='') as d_file, open(demo_gaze_dataset_file, 'w', newline='') as dg_file:
    d_writer = csv.writer(d_file)
    dg_writer = csv.writer(dg_file)

    for idx in range(dataset.dataset_size):
        # get state info
        s = dataset.all_states[idx]
        agent = s['agent']
        # skip invalid states
        if agent[2]==0:
            continue
        car = s['car']
        dest = s['dest']

        # Flatten the state list
        state = agent + sum(car, []) + dest

        # get action info
        action = dataset.all_frame_action[idx]
        # get penalty for demo feedback
        demo_val = dataset.all_frame_demo_rewards[idx]
        # get penalty for demo-gaze feedback
        demo_gaze_val = dataset.all_frame_demo_gaze_rewards[idx]

        demo_penalty = 0 if demo_val in [-1.0, 100.0] else 1
        demo_gaze_penalty = 0 if demo_gaze_val in [-1.0, 100.0] else 1

        d_writer.writerow([*state, action, demo_penalty])
        dg_writer.writerow([*state, action, demo_gaze_penalty])
