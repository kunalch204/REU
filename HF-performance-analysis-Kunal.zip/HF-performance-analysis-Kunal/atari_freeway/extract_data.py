import numpy as np
import  tarfile, cv2, time, os, math
from pathlib import Path
import json

radius = 5

def get_state(RGB_img):
    """
    Parse *RGB* (same format as from ALE) frame of Freeway into state dict
    by picking out unique colors of each object.
    Absent agent/cars are filled with [None x 4] to match shape.

    :param RGB_img: input game frame as from ALE. shape: 210x160x3.
    :return: frame_dict: {'agent': [y1, y2, x1, x2],              (shape: 4,)
                          'car': [[y1, y2, x1, x2] for each car], (shape: 10x4)
                          'dest': [[y1, y2, x1, x2]]}               (shape: 1x4)
             Note here the y-then-x convention follows matrix access convention.
             All coordinates are in lists.
             'dest' is in 2d list b/c we always assume there are multiple objects for a module.
    """

    AGENT_COLOR = [(84, 252, 252), (124, 236, 224)]
    COLOR_MAP = {'car0': (26, 26, 167),
                 'car1': (117, 231, 180),
                 'car2': (15, 105, 105),
                 'car3': (111, 111, 228),
                 'car4': (167, 26, 24),
                 'car5': (33, 98, 162),
                 'car6': (214, 92, 84),
                 'car7': (50, 50, 184),
                 'car8': (84, 183, 135),
                 'car9': (64, 210, 210)}
    center_line_fname = "data/freeway_center_line.png"

    state = {'agent': [0 for _ in range(4)],
             'car': None,
             'dest': None}

    # === agent chic ===
    mask1 = cv2.inRange(RGB_img, AGENT_COLOR[0], AGENT_COLOR[0])
    mask2 = cv2.inRange(RGB_img, np.array(AGENT_COLOR[1]), np.array(AGENT_COLOR[1]))
    mask = mask1 + mask2
    # take out center line
    center_line_mask = cv2.imread(center_line_fname)
    center_line_mask = cv2.cvtColor(center_line_mask, cv2.COLOR_BGR2GRAY)
    # limit to a column where the first chicken walks
    mask = (mask - center_line_mask)[:, 40:50]
    if np.any(mask):
        y1 = min(np.nonzero(mask)[0])
        y2 = max(np.nonzero(mask)[0])
        # eliminate when chic at both start & dest (e.g. at beginning of new walk)
        # if y2 - y1 < 10:
        x1 = min(np.nonzero(mask)[1]) + 40
        x2 = max(np.nonzero(mask)[1]) + 40
        state['agent'] = [int(y1), int(y2), int(x1), int(x2)]
        if state['agent'] == [16, 194, 44, 49]:
            state['agent'] = [187, 194, 44, 49]
    # get radius co-ords around the agent
    ch_y1, ch_y2, ch_x1, ch_x2 = state['agent']
    ch_rad_x1, ch_rad_y1 = ch_x1-20, ch_y1-20
    ch_rad_x2, ch_rad_y2 = ch_x2+20, ch_y2+20

    # === car module ===
    car_states = []
    for obj in COLOR_MAP:
        # mask = cv2.inRange(BGR_img, np.array(COLOR_MAP[obj]), np.array(COLOR_MAP[obj]))
        mask = cv2.inRange(RGB_img, COLOR_MAP[obj], COLOR_MAP[obj])
        if obj == 'car3':
            # car3 color == logo & score, so only take its lane
            mask = mask[75:90, :]
            if np.any(mask):
                y1 = min(np.nonzero(mask)[0]) + 75 - 1  # 75: vertical offset; 1: wheels
                y2 = max(np.nonzero(mask)[0]) + 75 + 1
                x1 = min(np.nonzero(mask)[1])
                x2 = max(np.nonzero(mask)[1])
            #     car_states.append([int(y1), int(y2), int(x1), int(x2)])

            # else:
            #     car_states.append([0, 0, 0, 0])
        else:
            # other cars
            if np.any(mask):
                y1 = min(np.nonzero(mask)[0]) - 1
                y2 = max(np.nonzero(mask)[0]) + 1
                x1 = min(np.nonzero(mask)[1])
                x2 = max(np.nonzero(mask)[1])
            #     car_states.append([int(y1), int(y2), int(x1), int(x2)])
            # else:
            #     car_states.append([0, 0, 0, 0])
        if (ch_rad_x1<=x1) and (x2<=ch_rad_x2) and (ch_rad_y1<=y1) and (y2<=ch_rad_y2):
            car_states.append([int(y1), int(y2), int(x1), int(x2)])
        else:
            car_states.append([0, 0, 0, 0])

    state['car'] = car_states


    # init coord: true dest
    state['dest'] = [16, 24, 44, 49]
    if state['agent'] == [16, 23, 44, 49]:
        state['agent'] = [16, 24, 44, 49]

    ## --------------sanity check----------------------------
    # if any(sublist!=[0, 0, 0, 0] for sublist in state['car']):
    #     print("updated state: ", state)
    #     input('press enter')

    return state

def get_mdp_reward(prev_state, curr_state, curr_gaze, curr_action):
    agent_curr_pos = curr_state['agent']
    ch_y0, ch_y1, ch_x0, ch_x1 = agent_curr_pos
    # radius around the chicken to check [demo-gaze]
    ch_rad_x0, ch_rad_y0 = int(ch_x0-20), int(ch_y0-20)
    ch_rad_x1, ch_rad_y1 = int(ch_x1+20), int(ch_y1+20)
    # get center point for chicken
    y0 = (ch_y0+ch_y1)/2

    prev_chic_pos = prev_state['agent']
    pr_ch_y0, pr_ch_y1, pr_ch_x0, pr_ch_x1 = prev_chic_pos
    prev_y0 = (pr_ch_y0+pr_ch_y1)/2

    dest = curr_state['dest']

    curr_gaze = np.array(curr_gaze)
    gaze_in_range = []
    for g in curr_gaze:
        if (ch_rad_x0<=g[0]<=ch_rad_x1) and (ch_rad_y0<=g[1]<=ch_rad_y1):
            gaze_in_range.append(g)

    reward_struct = {
                    'goal': 100,
                    'hit_penalty': -10,
                    'gaze': -1,
                    'step': -1
                    }

    f_demo_reward, f_demo_gaze_reward = reward_struct['step'], reward_struct['step']
    if agent_curr_pos == [187, 194, 44, 49]: # start position
        f_demo_reward, f_demo_gaze_reward = reward_struct['step'], reward_struct['step']
    elif agent_curr_pos == dest: # reached goal
        f_demo_reward, f_demo_gaze_reward = reward_struct['goal'], reward_struct['goal']

    if prev_y0 > y0:  # one step closer to goal
        f_demo_reward = reward_struct['step']
        if curr_action == 0:
            f_demo_gaze_reward = reward_struct['step']
        elif gaze_in_range:
            penalties = [compute_gaze_penalty(car, g, curr_state['agent'], curr_action, reward_struct) for g in gaze_in_range for car in curr_state['car'] if car != [0, 0, 0, 0]]
            if penalties!=[]:
                f_demo_gaze_reward = np.average(penalties)
            else:
                f_demo_gaze_reward = reward_struct['step']

    # hit by a car
    hit_penalty = get_hit_penalty(curr_state)
    if np.sum(hit_penalty) < 0:
        f_demo_reward = f_demo_gaze_reward = reward_struct['hit_penalty']

    return f_demo_reward, f_demo_gaze_reward

def compute_gaze_penalty(car, g, agent, curr_action, reward_struct):
    car_y0, car_y1, car_x0, car_x1 = car
    agent_y0, agent_y1 = agent[:2]

    if car_x0 - 5 <= g[0] < car_x1 + 5 and car_y0 - 5 <= g[1] < car_y1 + 5: # gaze on any car in radius of the agent
        if curr_action == 2 and car_y1 <= agent_y0:
            return reward_struct['step'] + reward_struct['gaze']
        elif curr_action == 5 and car_y0 >= agent_y1:
            return reward_struct['step'] + reward_struct['gaze']

    return reward_struct['step']

def get_hit_penalty(curr_state):
    agent_curr_pos = curr_state['agent']
    ch_x0, ch_y0 = agent_curr_pos[2], agent_curr_pos[0]
    ch_x1, ch_y1 = agent_curr_pos[3], agent_curr_pos[1]
    # get center point for chicken
    x0 = (ch_x0+ch_x1)/2
    y0 = (ch_y0+ch_y1)/2
    cars_pos = curr_state['car']
    hit_penalty = np.zeros(10)
    for car_idx, car in enumerate(cars_pos):
        car_x0, car_y0 = car[2], car[0]
        car_x1, car_y1 = car[3], car[1]
        # get center point for car
        x1 = (car_x0+car_x1)/2
        y1 = (car_y0+car_y1)/2

        d=math.sqrt((x1-x0)**2 + (y1-y0)**2)
        # intersecting circles;
        # d = 2r [intersects at 1 pt];
        # d < 2r [intersects at 2 pts]
        # d = 0 [coincident circles]
        # d > 0 [intersecting circles]
        if d >= 0 and d < (2*radius):
            hit_penalty[car_idx] = -5
    return hit_penalty

def write_dataset(dataset, filename):
    filename = Path(filename)
    filename.parent.mkdir(parents=True, exist_ok=True)

    dataset_dict = vars(dataset)
    for it in dataset_dict:
        if isinstance(dataset_dict[it], np.ndarray):
            dataset_dict[it] = dataset_dict[it].tolist()
    print("Write in json file complete...")
    # return dataset_dict
    with open(filename, 'w') as fp:
        json.dump(dataset_dict, fp)


class Dataset:
  def __init__(self, tar_fname, label_fname):
    t1=time.time()
    print ("Read all training data into memory...")
    self.n_actions = 3
    self.action_space = {0: "No-op", 2: "Up", 5: "Down"}
    # Get action labels from txt file
    frame_ids, lbls = [], []
    rewards, gaze_positions = [], []
    with open(label_fname,'r') as f:
        for line_idx, line in enumerate(f):
            if line.startswith("frame_id") or line == "":
                continue # skip head or empty lines
            pos_per_frame = []
            dataline = line.split(',')
            frame_id, lbl = dataline[0], dataline[5]
            reward = dataline[4]
            read_gaze = dataline[6:]
            if lbl == "null": # end of file
                break
            frame_ids.append(frame_id)
            lbls.append(int(lbl))
            rewards.append(int(reward))
            if len(read_gaze) == 1:
                pos_per_frame.append((0, 0))
            else:
                for i in range(0, len(read_gaze), 2):
                    x, y = float(read_gaze[i]), float(read_gaze[i+1])
                    if (x < 0) or (y < 0) or (x > 160) or (y > 210):
                        pos_per_frame.append((0, 0))
                    else:
                        pos_per_frame.append((float(read_gaze[i]), float(read_gaze[i+1])))
            gaze_positions.append(pos_per_frame)
    self.all_frame_action = np.asarray(lbls, dtype=np.int32) # all frame2action labels
    self.dataset_size = len(self.all_frame_action)
    self.all_frame_ids = np.asarray(frame_ids) # all frame ids
    self.all_frame_gaze_pos = gaze_positions
    self.all_frame_rewards = np.asarray(rewards)

    # Read training images from tar file
    imgs = [None] * self.dataset_size
    print("Making a temp dir and uncompressing PNG tar file")
    temp_extract_dir = "data/img_data_tmp/"
    if not os.path.exists(temp_extract_dir):
        os.mkdir(temp_extract_dir)
    tar = tarfile.open(tar_fname, 'r')
    tar.extractall(temp_extract_dir)
    png_files = tar.getnames()
    # get the full path
    temp_extract_full_path_dir = temp_extract_dir + png_files[0].split('/')[0]
    print("Uncompressed PNG tar file into temporary directory: " + temp_extract_full_path_dir)

    print("Reading images...")
    states = []
    demo_rewards, demo_gaze_rewards = [], []
    num_trajs = 0
    goal_states = []
    for i in range(self.dataset_size):
        # print(self.all_frame_ids[i])
        curr_agent_action = self.all_frame_action[i]
        curr_frame_id = self.all_frame_ids[i]
        curr_frame_gaze = self.all_frame_gaze_pos[i]
        curr_png_fname = temp_extract_full_path_dir + '/' + curr_frame_id + '.png'
        curr_img = cv2.imread(curr_png_fname)
        curr_img_state = get_state(curr_img)

        if curr_img_state['agent'] == curr_img_state['dest']:
            num_trajs += 1
            goal_states.append(i)

        prev_idx = i-1
        if prev_idx == -1:
            prev_idx = 0

        prev_frame_id = self.all_frame_ids[prev_idx]
        prev_png_fname = temp_extract_full_path_dir + '/' + prev_frame_id + '.png'
        prev_img = cv2.imread(prev_png_fname)
        prev_img_state = get_state(prev_img)
        # print("curr state: ", curr_img_state)
        # print("prev state: ", prev_img_state)

        f_demo_reward, f_demo_gaze_reward = get_mdp_reward(prev_img_state, curr_img_state, curr_frame_gaze, curr_agent_action)
        states.append(curr_img_state)
        # imgs[i] = copy.deepcopy(curr_img)
        demo_rewards.append(f_demo_reward)
        demo_gaze_rewards.append(f_demo_gaze_reward)
        #print("\r%d/%d" % (i+1,self.size)),
        #sys.stdout.flush()

    # self.all_frames = np.asarray(imgs)
    self.all_states = np.asarray(states)
    self.all_frame_demo_rewards = np.asarray(demo_rewards)
    self.all_frame_demo_gaze_rewards = np.asarray(demo_gaze_rewards)
    self.num_trajs = num_trajs
    self.goal_states = goal_states
    print ("Time spent to read training data: %.1fs" % (time.time()-t1))
