import numpy as np

from feedback.value_iteration import valueIteration
from feedback.demo_action_mismatch import d_am
from feedback.approval import get_approval
from feedback.corrections import get_corrections

def multiple_fb(train_grid, train_grid_oracle_policy, iterations, output_dir):
    feedback_methods = [['dam', 'approval', 'corrections'], ['dam', 'corrections', 'approval'],
                        ['approval', 'dam', 'corrections'], ['approval', 'corrections', 'dam'],
                        ['corrections', 'approval', 'dam'], ['corrections', 'dam', 'approval'],
                        ['dam', 'approval'], ['dam', 'corrections'],
                        ['approval', 'dam'], ['approval', 'corrections'],
                        ['corrections', 'approval'], ['corrections', 'dam']]

    for set in feedback_methods:
        if len(set) == 2:
            feedback_name = str(set[0][0]) + "-" + str(set[1][0])
        else:
            feedback_name = str(set[0][0]) + "-" + str(set[1][0]) + "-" + str(set[2][0])
        print("{} Feedback method: {}".format('-'*15, feedback_name))


        for iter in iterations:
            train_grid.reset()
            _, train_grid_agent_policy = valueIteration(train_grid, is_oracle=False)
            num_queries = 0
            num_queries = [int(iter/len(set))]

            for method in set:
                if method == 'dam':
                    d_am(train_grid, train_grid_oracle_policy, train_grid_agent_policy, num_queries, output_dir, method=feedback_name+'/DAM', run_multiple_feedbacks=True)
                elif method == 'approval':
                    get_approval(train_grid, train_grid_oracle_policy, train_grid_agent_policy, num_queries, output_dir, method=feedback_name+'/App', run_multiple_feedbacks=True)
                elif method == 'corrections':
                    get_corrections(train_grid, train_grid_oracle_policy, train_grid_agent_policy, num_queries, output_dir, method=feedback_name+'/Corr', run_multiple_feedbacks=True)
