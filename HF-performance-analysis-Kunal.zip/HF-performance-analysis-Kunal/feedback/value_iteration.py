import numpy as np
import time

def valueIteration(grid, is_oracle=True, gamma=0.99, epsilon=0.01):
    nA = grid.num_actions
    nRows = grid.rows
    nCols = grid.cols

    v_new = np.zeros((nRows, nCols))
    pi_new = np.zeros((nRows, nCols))

    factoredStates = grid.getStateFactorRep()

    time3_start = time.time()
    while True:
        v = v_new.copy()
        delta = 0
        for state in factoredStates:
            (x,y), _ = state
            value = []
            for action in range(nA):
                value.append(sum([trans_prob*(v[next_state[0][0]][next_state[0][1]]) for (next_state, trans_prob) in grid.get_successors(state, action)]) )

                if grid.is_goal(state) == True:
                    value[action] = grid.get_reward(state, action, is_oracle)
                    continue

                if (tuple(state), action) in grid.agent_reward_cache:
                    reward = grid.agent_reward_cache[(tuple(state), action)]
                else:
                    reward = grid.get_reward(state, action, is_oracle)
                value[action] = reward + gamma * value[action]
            v_new[x][y] = max(value)
            pi_new[x][y] = value.index(max(value))
            delta = max(delta, abs((v_new[x][y]) - (v[x][y])))


        if delta < epsilon:
            time3_end = time.time()
            print("time3: {}".format(time3_end-time3_start))
            return v_new, pi_new
