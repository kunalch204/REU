from feedback.helper_functions import *
from feedback.value_iteration import valueIteration
import numpy as np

def get_corrections(train_grid, oracle_policy, multiple_fb_agent_policy, budgets, output_dir, method='Corr', run_multiple_feedbacks=False):

    train_grid_agent_policy = np.zeros((train_grid.rows, train_grid.cols))
    _, train_grid_agent_policy = valueIteration(train_grid, is_oracle=False)
    if run_multiple_feedbacks:
        train_grid_agent_policy = multiple_fb_agent_policy

    for curr_budget in budgets:
        print("C current budget: ", curr_budget)
        agent_trajs = get_demonstration(train_grid, num_trials=curr_budget, policy=train_grid_agent_policy, is_oracle=False)

        all_sa_pairs = get_all_sa_pairs(train_grid)
        if agent_trajs != None:
            for sa_pair in all_sa_pairs:
                state, action = sa_pair[0], sa_pair[1]
                if (state, action) not in train_grid.learned_reward_cache:
                    train_grid.learned_reward_cache[(tuple(state), action)] = 0
                if state in agent_trajs:
                    action = agent_trajs[state]
                    if is_safe_action(state, action) == False:
                        safe_action = int(oracle_policy[state[0]])
                        for a in range(train_grid.num_actions):
                            if a != safe_action:
                                train_grid.learned_reward_cache[(tuple(state), a)] = 1
        learned_reward_to_file(train_grid, output_dir+"learnFromOracle_{}/".format('multiFB' if run_multiple_feedbacks else 'singleFB'), curr_budget, file_title=method)

        if not run_multiple_feedbacks:
            train_grid.reset()
