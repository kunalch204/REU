from feedback.helper_functions import *

def get_approval(train_grid, oracle_policy, multiple_fb_agent_policy, budgets, output_dir, method, run_multiple_feedbacks=False):

    max_allowed_budget = (train_grid.num_states-train_grid.num_walls)*train_grid.num_actions
    for budget in budgets:
        print("A current budget: {}".format(budget))

        if budget > max_allowed_budget:
            curr_budget = max_allowed_budget
        else:
            curr_budget = budget

        random_sa_pairs = get_random_state_action_pairs(train_grid, curr_budget)
        all_sa_pairs = get_all_sa_pairs(train_grid)

        for sa_pair in all_sa_pairs:
            state, action = sa_pair[0], sa_pair[1]
            if (state, action) not in train_grid.learned_reward_cache:
                train_grid.learned_reward_cache[(state, action)] = 0
            if (state, action) in random_sa_pairs:
                if is_safe_action(state, action) == False:
                    safe_action = int(oracle_policy[state[0]])
                    if action != safe_action:
                        train_grid.learned_reward_cache[(tuple(state), action)] = 1
        learned_reward_to_file(train_grid, output_dir+"learnFromOracle_{}/".format('multiFB' if run_multiple_feedbacks else 'singleFB'), curr_budget, file_title=method)

        if not run_multiple_feedbacks:
            train_grid.reset()
