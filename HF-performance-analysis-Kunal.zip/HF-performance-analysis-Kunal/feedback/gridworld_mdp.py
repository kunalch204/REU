import numpy as np
from ai_safety_gridworlds.environments.shared.safety_game import *

class envMDP:
    def __init__(self, grid):
        self.env = grid
        self.grid = grid.last_observations['board']
        self.reset()
        # grid list should have letters in place of numbers
        self._value_mapping = {0:'#', 1:' ', 2:'A', 3:'V', 4:'G'}
        self.grid_list = [[self._value_mapping[self.grid[i][j]] for j in range(len(self.grid[i]))] for i in range(len(self.grid))]
        self.num_actions = len(range(grid.action_spec().maximum + 1))
        self.state = ((np.where(self.grid == 2)[0].item(), np.where(self.grid == 2)[1].item()), False)
        self.terminal_state = None
        self.rows = len(self.grid)
        self.cols = len(self.grid[0])
        self.num_states = self.rows * self.cols
        # self.num_states_not_wall = self.num_states - self.grid_list.count(['#'])
        self.agent_reward_cache = {}
        self.learned_reward_cache = {}
        self.oracle_demos = {}
        self.action_space = {0: Actions.LEFT, 1: Actions.UP, 2: Actions.RIGHT, 3: Actions.DOWN}
        self.num_walls = 0
        for i in self.grid_list:
            self.num_walls += i.count('#')

    def reset(self, full_grid=True):
        if full_grid==False:
            self.state = ((np.where(self.grid == 2)[0].item(), np.where(self.grid == 2)[1].item()), False)
        else:
            self.state = ((np.where(self.grid == 2)[0].item(), np.where(self.grid == 2)[1].item()), False)
            self.agent_reward_cache = {}
            self.learned_reward_cache = {}
            self.oracle_demos = {}

    def getStateFactorRep(self):
        featureRep = [] # records [(int x, int y), bool state_feature]
        for i in range(self.rows):
            for j in range(self.cols):
                currState = self.grid_list[i][j]
                if currState == 'G':
                    self.terminal_state = [(i, j), False]

                if currState == 'V':
                    featureRep.append([(i, j), True])
                elif currState != '#':
                    featureRep.append([(i, j), False])
        return featureRep

    def step(self, action, evaluate=False):
        terminal = False
        factoredNextStates = self.get_successors(self.state, action)
        s_prime, prob = [], []
        for i in factoredNextStates:
            s_prime.append(i[0])
            prob.append(i[1])
        # np.random.seed(42)
        next_state_idx = np.random.choice(len(s_prime), p=prob)
        # print("next_state_idx: {}".format(next_state_idx))
        # input()
        self.state = s_prime[next_state_idx]
        reward = self.get_reward(self.state, action)
        if self.is_goal(self.state):
            terminal = True
        if evaluate:
            state_feature = False
            if self.state[1] == True:
                state_feature = True
            return s_prime[next_state_idx], reward, prob[next_state_idx], terminal, state_feature
        elif not evaluate:
            return s_prime[next_state_idx], reward, prob[next_state_idx], terminal

    def getActionFactorRep(self, a):
        if a == 0: # left
            return (0,-1)
        elif a == 1: # up
            return (-1,0)
        elif a == 2: # right
            return (0,1)
        else: # down
            return (1,0)

    def is_boundary(self, state):
        x, y = state
        return (x <= 0 or x >= self.rows-1 or y <= 0 or y >= self.cols-1 )
        # return (x < 0 or x > self.rows-1 or y < 0 or y > self.cols-1)

    def is_goal(self, state):
        return state == self.terminal_state

    def move(self, currFactoredState, action):
        state, state_feature = currFactoredState
        new_state = tuple(x + y for (x, y) in zip(state, self.getActionFactorRep(action)))
        if self.is_boundary(new_state):
            # self.state = currFactoredState
            return currFactoredState, True
        else:
            if self.grid_list[new_state[0]][new_state[1]] == 'V':
                # self.state = [new_state, True]
                return [new_state, True], False
            else:
                # self.state = [new_state, False]
                return [new_state, False], False

    def get_side_states(self, state, action):
        side_states =[]
        for a in range(self.num_actions):
            if a != action:
                new_state, is_wall = self.move(state, a)
                if not is_wall:
                    side_states.append(new_state)
                elif is_wall:
                    side_states.append(list(state))
        return side_states

    def getTransitionFactorRep(self, curr_state, action, next_state): # FINAL ENVIRONMENT SETTINGS
        '''
        curr_state: current state, format: [(int x, int y), bool state_feature]
        action: [int a]
        next_state: [(int x, int y), bool state_feature]
        '''
        succ_factored_state, is_wall = self.move(curr_state, action)
        # print("\ncurr_state: {}, next_state: {}, succ_factored_state: {}".format(curr_state, next_state, succ_factored_state))
        sstates = self.get_side_states(curr_state, action)
        # print("sstates: {}".format(sstates))

        success_prob = 0.8
        fail_prob = 0.2/3

        if is_wall:
            # print("hit boundary")
            transition_probs = []
            for feature_idx in range(len(curr_state)):
                if (curr_state[feature_idx] == next_state[feature_idx]):
                    transition_probs.append(1)
                else:
                    transition_probs.append(0)
            return np.prod(transition_probs)

        elif not is_wall:
            transition_probs = []
            if (next_state[0]==succ_factored_state[0]):
                transition_probs.append(success_prob)
                if (next_state[1]==succ_factored_state[1]):
                    transition_probs.append(1)
                elif (next_state[1]!=succ_factored_state[1]):
                    transition_probs.append(0)
                return np.prod(transition_probs)

            for side_state in sstates:
                if (next_state[0]==side_state[0]):
                    state_count = sstates.count(next_state)
                    fail_prob *= state_count
                    transition_probs.append(fail_prob)
                    if (next_state[1]==side_state[1]):
                        transition_probs.append(1)
                    elif (next_state[1]!=side_state[1]):
                        transition_probs.append(0)
                    return np.prod(transition_probs)

        return 0

    def get_successors(self, state, action):
        successors = []
        factored_states = self.getStateFactorRep()
        for next_state in factored_states:
            p = self.getTransitionFactorRep(state, action, next_state)
            if p > 0:
                successors.append((next_state, p))
        return successors

    def get_reward(self, factoredStateRep, action, is_oracle=True):
        (x,y), state_feature = factoredStateRep
        state_reward = 0
        if action in [0,1,2,3]:
            if is_oracle:
                if self.is_goal(factoredStateRep) == True:
                    state_reward = 100
                elif state_feature == True:
                    state_reward = -10
                else:
                    state_reward = -1
            else:
                if self.is_goal(factoredStateRep) == True:
                    state_reward = 100
                else:
                    state_reward = -1
        return state_reward
