from feedback.demo_action_mismatch import d_am
from feedback.approval import get_approval
from feedback.corrections import get_corrections

def single_fb(train_grid, train_grid_oracle_policy, iterations, output_dir):

    initial_agent_policy = None
    # Approval
    train_grid.reset()
    print('{} Approval {}'.format('-'*10, '-'*10))
    get_approval(train_grid, train_grid_oracle_policy, initial_agent_policy, iterations, output_dir, method='App', run_multiple_feedbacks=False)

    # Corrections
    train_grid.reset()
    print('{} Correction {}'.format('-'*10, '-'*10))
    get_corrections(train_grid, train_grid_oracle_policy, initial_agent_policy, iterations, output_dir, method='Corr', run_multiple_feedbacks=False)

    # Demo_Action_Mismatch
    train_grid.reset()
    print('{} DAM {}'.format('-'*10, '-'*10))
    d_am(train_grid, train_grid_oracle_policy, initial_agent_policy, iterations, output_dir, method='DAM', run_multiple_feedbacks=False)
