import numpy as np
import os
from pathlib import Path

from ai_safety_gridworlds.environments import side_effects_vase
from feedback.gridworld_mdp import envMDP
from feedback.value_iteration import valueIteration

def initialize_env(gridSize, game_level=0):
    side_effects_vase.GAME_ART = eval(open('gameArt/size{}.txt'.format(gridSize)).read())
    chosen_env = side_effects_vase.SideEffectsVaseEnvironment(level=game_level)
    chosen_env.reset()
    env = envMDP(chosen_env)
    env.reset()
    return env

def is_safe_action(state, action):
    if state[1] == True:
        if action in [0,1,2,3]:
            return False
    return True

def get_all_sa_pairs(grid):
    state_action_pairs = []
    for state in grid.getStateFactorRep():
        for action in range(grid.num_actions):
            state_action_pairs.append([tuple(state), action])
    return state_action_pairs

def simulate_trajectory(grid, policy):
    trajectory = []
    trial_reward = 0
    terminal= False
    grid.reset(full_grid=False)
    action = int(policy[grid.state[0]])
    trajectory.append([tuple(grid.state), action])
    observation, reward, _, terminal = grid.step(action)
    action = int(policy[observation[0]])
    trajectory.append([tuple(observation), action])
    trial_reward += reward
    while not terminal:
        observation, reward, _, terminal = grid.step(action)
        action = int(policy[observation[0]])
        trajectory.append([tuple(observation), action])
        trial_reward += reward
    return trial_reward, trajectory

def get_demonstration(grid, num_trials, policy, is_oracle=True):
    agent_demos = {}
    for _ in range(num_trials):
        _, trajectory = simulate_trajectory(grid, policy)
        for step in range(len(trajectory)):
            state = trajectory[step][0]
            action = trajectory[step][1]
            if is_oracle:
                if state not in grid.oracle_demos:
                    grid.oracle_demos[state] = action
            elif not is_oracle:
                if state not in agent_demos:
                    agent_demos[state] = action
    return agent_demos


def get_random_state_action_pairs(grid, curr_budget):
    state_action_pairs = []
    np.random.seed(42)
    num_states_not_wall = grid.num_states - grid.num_walls
    indices = np.random.choice(num_states_not_wall*grid.num_actions, int(curr_budget), replace=False)
    for idx in range(len(indices)):
        state_idx = indices[idx] // grid.num_actions
        random_state = grid.getStateFactorRep()[state_idx]
        agent_action = indices[idx] % grid.num_actions
        state_action_pairs.append((tuple(random_state), agent_action))
    return state_action_pairs


def get_state_action_successors(grid, policy):
    print('Generating test set...')
    state_action_pairs = [] # format: [(((x, y), traffic), action), ...]
    gt_penalty = 0
    for state in grid.getStateFactorRep():
        gt_action = int(policy[state[0][0], state[0][1]])
        for action in range(grid.num_actions):
            if grid.get_successors(state, action)!=[]:
                if (state[1]==True) and (action != gt_action):
                    gt_penalty = 1
                else:
                    gt_penalty = 0
                state_action_pairs.append((tuple(state), action, gt_penalty))
                # state_action_pairs.append([state[0][0], state[0][1], 0 if state[1]==False else 1, action])
    return state_action_pairs

def write_testset_to_file(grid, filename):
    _, grid_oracle_policy = valueIteration(grid, is_oracle=True)
    test_state_action_pairs = get_state_action_successors(grid, grid_oracle_policy)
    Path(filename).parent.mkdir(parents=True, exist_ok=True)
    with open(filename, 'w') as f:
        if os.stat(filename).st_size == 0:
            f.write("state, action, gt_penalty\n")
        for sa_pair in test_state_action_pairs:
            f.write('({},{},{})\n'.format(sa_pair[0], sa_pair[1], sa_pair[2]))
        f.close()


def learned_reward_to_file(grid, output_dir, curr_budget, file_title):
    filename = Path(output_dir+file_title+'.csv')
    filename.parent.mkdir(parents=True, exist_ok=True)

    with open(filename, 'a') as f:
        if os.stat(filename).st_size == 0:
            f.write("iteration,(state,action),penalty\n")
        for key, value in grid.learned_reward_cache.items():
            f.write('{},{},{}\n'.format(curr_budget, key, value))
        f.close()


def print_policy(env, pi, is_oracle=True):
    mapping = {0:'L', 1:'U', 2:'R', 3:'D'}
    # pi_letters = np.((env.rows, env.cols))
    pi_letters = np.chararray((env.rows, env.cols))
    for i in range(env.rows):
        for j in range(env.cols):
            pi_letters[i][j] = mapping[pi[i][j]]
            if env.grid_list[i][j] == '#':
                pi_letters[i][j] = '#'

    print("{} policy: \n{}".format('Oracle' if is_oracle==True else 'Agent', pi_letters.decode('utf-8')))
