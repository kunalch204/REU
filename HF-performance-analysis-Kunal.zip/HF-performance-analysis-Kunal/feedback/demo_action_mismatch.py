import numpy as np

from feedback.helper_functions import *
from feedback.value_iteration import valueIteration

def find_mismatch(grid, agent_policy):
    '''
    Find the mismatch between agent action and oracle action in all states and update the agent's learned reward cache
    '''
    all_sa_pairs = get_all_sa_pairs(grid)
    for sa_pair in all_sa_pairs:
        state, action = sa_pair[0], sa_pair[1]
        if (state, action) not in grid.learned_reward_cache:
            grid.learned_reward_cache[(state, action)] = 0
        agent_action = int(agent_policy[state[0]])
        if state in grid.oracle_demos:
            oracle_action = int(grid.oracle_demos[state])
            if agent_action != oracle_action:
                grid.learned_reward_cache[(state, agent_action)] = 1

def d_am(train_grid, oracle_policy, multi_fb_agent_policy, budgets, output_dir, method='DAM', run_multiple_feedbacks=False):

    train_grid_agent_policy = np.zeros((train_grid.rows, train_grid.cols))
    _, train_grid_agent_policy = valueIteration(train_grid, is_oracle=False) # agent initial policy
    if run_multiple_feedbacks:
        train_grid_agent_policy = multi_fb_agent_policy

    for curr_budget in budgets:
        print("DAM current budget: {}".format(curr_budget))
        get_demonstration(train_grid, num_trials=curr_budget, policy=oracle_policy) # update oracle demos
        find_mismatch(train_grid, train_grid_agent_policy) # update mismatch cost - agent learns from oracle demos
        learned_reward_to_file(train_grid, output_dir+"learnFromOracle_{}/".format('multiFB' if run_multiple_feedbacks else 'singleFB'), curr_budget, file_title=method)

        if not run_multiple_feedbacks:
            train_grid.reset()
